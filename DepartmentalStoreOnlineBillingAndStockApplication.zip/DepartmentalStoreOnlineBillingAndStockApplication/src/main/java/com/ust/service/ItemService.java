package com.ust.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.db.ItemRepository;
import com.ust.model.Item;

@Service
public class ItemService  {
 @Autowired
 ItemRepository repo;
 public Item addNewItem(Item item) {
		return repo.save(item);
	}
	
 /*public Item updateItem(Item item) {
		return repo.save(item);
		
	}
	public Item searchItem(Item item) {
	  Optional<Item> optional=repo.findById(item.getId());
	  if(optional.isPresent())
		  return optional.get();
	  else
		  return null;
}

public Item searchItem(int id) {
	  Optional<Item> optional=repo.findById(id);
	  if(optional.isPresent())
		  return optional.get();
	  else
		  return null;
}
public List<Item> getAllItems(){
	  return repo.findAll();
}
public boolean deleteItem(Item citem) {
	  repo.delete(item);
	  return true;
}
public List<Item> getItemsByName(String name){
	  return repo.findByName(name);
}
/*public Item getItemsByPhone(String phoneNumber){
	  return repo.findByPhoneNumber(phoneNumber);
}*/
}
