package com.ust.dto.request;

import com.ust.model.Item;

public class ItemAddRequest {
	 Item item;

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}


	 
	}
