package com.ust.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.dto.request.ItemAddRequest;
import com.ust.dto.response.ItemAddResponse;
import com.ust.model.Item;
import com.ust.service.ItemService;

@RestController
@RequestMapping(value = "/api")
public class ItemController {
	@Autowired
	ItemService service;

	@PostMapping(value = "/add")
	public ResponseEntity<ItemAddResponse> f1(@RequestBody ItemAddRequest request) {
		Item item1 = this.service.addNewItem(request.getItem());
		ItemAddResponse response = new ItemAddResponse();
		response.setStatusCode(200);
		response.setDescription("Item Added Successfully");
		response.setItem(item1);
		return new ResponseEntity<>(response,HttpStatus.CREATED);

	}

/*	@PutMapping(value = "/modify")
	public ResponseEntity<CustomerModifyResponse> f2(@RequestBody CustomerUpdateRequest request) {
		CustomerModifyResponse response = new CustomerModifyResponse();
		Customer customer1 = this.service.searchCustomer(request.getCustomer());
		if (customer1 != null) {
			Customer customer2 = this.service.updateCustomer(request.getCustomer());

			response.setStatusCode(200);
			response.setDescription("Customer Modified Successfully");
			response.setCustomer(customer2);
			return ResponseEntity.ok(response);
		} else {
			response.setStatusCode(404);
			response.setDescription("Customer Not Found for Modification");
			response.setCustomer(null);
			return new ResponseEntity<CustomerModifyResponse>(response, HttpStatus.NOT_FOUND);
		}

		// return new ResponseEntity<Visitor>(visitor1, HttpStatus.OK);
	}

	@GetMapping(value = "/find/{custid}")
	public ResponseEntity<CustomerSearchResponse> f3(@PathVariable(name = "custid") int custid) throws Exception {
		CustomerSearchResponse response = new CustomerSearchResponse();
		Customer customer = this.service.searchCustomer(custid);
		if (customer != null) {
			response.setStatusCode(200);
			response.setDescription("Customer Fetched Successfully");
			response.setCustomer(customer);
			return new ResponseEntity<CustomerSearchResponse>(response, HttpStatus.OK);
		} else {
			Exception exception = new CustomerNotFoundException("Customer Not Found");
			throw exception;
		}

		
	}

	@GetMapping(value = "/showAll", produces = { MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<CustomerShowAllResponse> f4() {
		List<Customer> customers = this.service.getAllCustomers();
		CustomerShowAllResponse response = new CustomerShowAllResponse();
		response.setStatusCode(200);
		response.setDescription("All Customers Fetched");
		response.setCustomers(customers);
		return ResponseEntity.ok(response);
	}

	@DeleteMapping(value = "/delete")
	public ResponseEntity<CustomerDeleteResponse> f5(@RequestBody CustomerDeleteRequest request) {
		CustomerDeleteResponse response = new CustomerDeleteResponse();
		Customer customer1 = this.service.searchCustomer(request.getCustomer());
		if (customer1 != null) {

			try {
				this.service.deleteCustomer(request.getCustomer());
				response.setStatusCode(200);
				response.setDescription("Customer Deleted Successfully");
				response.setDeleteStatus(true);
				return ResponseEntity.ok().body(response);

			} catch (Exception e) {
				// return new ResponseEntity<Boolean>(true,HttpStatus.OK);
				response.setStatusCode(500);
				response.setDescription("Customer Not Deleted");
				response.setDeleteStatus(false);
				return ResponseEntity.internalServerError().body(response);
			}
		} else {
			response.setStatusCode(404);
			response.setDescription("Customer Not Found");
			response.setDeleteStatus(false);
			return new ResponseEntity(response, HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping(value = "/showAllByName/{name}")
	public ResponseEntity<CustomerShowAllByNameResponse> f6(@PathVariable(name = "name") String name) {
		CustomerShowAllByNameResponse response = new CustomerShowAllByNameResponse();
		List<Customer> customersBySameName = this.service.getCustomersByName(name);
		if (customersBySameName.isEmpty()) {
			response.setStatusCode(200);
			response.setDescription("There are no Customers by same name" + name);
			response.setVisitors(customersBySameName);
		} else {
			response.setStatusCode(200);
			response.setDescription("There are" + customersBySameName.size() + "with same name" + name);
			response.setVisitors(customersBySameName);
		}
		return ResponseEntity.ok(response);
	}

	@GetMapping(value = "/showAllByPhone", produces = { MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<CustomerShowPhoneResponse> f7(@RequestParam(name = "txt_phoneNumber") String phoneNumber) {
		CustomerShowPhoneResponse response = new CustomerShowPhoneResponse();
		Customer customerByPhone = this.service.getCustomersByPhone(phoneNumber);
		if (customerByPhone!=null) {
			response.setStatusCode(200);
			response.setDescription("There are no Customers having same phone" + phoneNumber);
			response.setCustomer(customerByPhone);
		} else {
			response.setStatusCode(200);
			response.setDescription("There are" + customerByPhone + "with same phone" + phoneNumber);
			response.setCustomer(customerByPhone);
		}
		return ResponseEntity.ok(response);
	}*/
}