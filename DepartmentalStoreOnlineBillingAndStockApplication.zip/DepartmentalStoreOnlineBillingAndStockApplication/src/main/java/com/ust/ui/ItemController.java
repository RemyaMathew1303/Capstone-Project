package com.ust.ui;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.dto.request.ItemAddRequest;
import com.ust.dto.request.ItemDeleteRequest;
import com.ust.dto.request.ItemUpdateRequest;
import com.ust.dto.response.ItemAddResponse;
import com.ust.dto.response.ItemDeleteResponse;
import com.ust.dto.response.ItemModifyResponse;
import com.ust.dto.response.ItemSearchResponse;
import com.ust.dto.response.ItemShowAllByNameResponse;
import com.ust.dto.response.ItemShowAllResponse;
import com.ust.exception.ItemNotFoundException;
import com.ust.model.Item;
import com.ust.service.ItemService;

@RestController
@RequestMapping(value = "/api")
public class ItemController {
	@Autowired
	ItemService service;

	@PostMapping(value = "/add")
	public ResponseEntity<ItemAddResponse> f1(@RequestBody ItemAddRequest request) {
		Item item1 = this.service.addNewItem(request.getItem());
		ItemAddResponse response = new ItemAddResponse();
		response.setStatusCode(200);
		response.setDescription("Item Added Successfully");
		response.setItem(item1);
		return new ResponseEntity<>(response, HttpStatus.CREATED);

	}

	@PutMapping(value = "/modify")
	public ResponseEntity<ItemModifyResponse> f2(@RequestBody ItemUpdateRequest request) {
		ItemModifyResponse response = new ItemModifyResponse();
		Item item1 = this.service.searchItem(request.getItem());
		if (item1 != null) {
			Item item2 = this.service.updateItem(request.getItem());

			response.setStatusCode(200);
			response.setDescription("Item Modified Successfully");
			response.setItem(item2);
			return ResponseEntity.ok(response);
		} else {
			response.setStatusCode(404);
			response.setDescription("Item Not Found for Modification");
			response.setItem(null);
			return new ResponseEntity<ItemModifyResponse>(response, HttpStatus.NOT_FOUND);
		}

		// return new ResponseEntity<Visitor>(visitor1, HttpStatus.OK);
	}

	@GetMapping(value = "/find/{custid}")
	public ResponseEntity<ItemSearchResponse> f3(@PathVariable(name = "custid") int custid) throws Exception {
		ItemSearchResponse response = new ItemSearchResponse();
		Item item = this.service.searchItem(custid);
		if (item != null) {
			response.setStatusCode(200);
			response.setDescription("Item Fetched Successfully");
			response.setItem(item);
			return new ResponseEntity<ItemSearchResponse>(response, HttpStatus.OK);
		} else {
			Exception exception = new ItemNotFoundException("Customer Not Found");
			throw exception;
		}

	}

	@GetMapping(value = "/showAll", produces = { MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<ItemShowAllResponse> f4() {
		List<Item> items = this.service.getAllItems();
		ItemShowAllResponse response = new ItemShowAllResponse();
		response.setStatusCode(200);
		response.setDescription("All Items Fetched");
		response.setItems(items);
		return ResponseEntity.ok(response);
	}

	@DeleteMapping(value = "/delete")
	public ResponseEntity<ItemDeleteResponse> f5(@RequestBody ItemDeleteRequest request) {
		ItemDeleteResponse response = new ItemDeleteResponse();
		Item item1 = this.service.searchItem(request.getItem());
		if (item1 != null) {

			try {
				this.service.deleteItem(request.getItem());
				response.setStatusCode(200);
				response.setDescription("Item Deleted Successfully");
				response.setDeleteStatus(true);
				return ResponseEntity.ok().body(response);

			} catch (Exception e) {
				// return new ResponseEntity<Boolean>(true,HttpStatus.OK);
				response.setStatusCode(500);
				response.setDescription("Item Not Deleted");
				response.setDeleteStatus(false);
				return ResponseEntity.internalServerError().body(response);
			}
		} else {
			response.setStatusCode(404);
			response.setDescription("Item Not Found");
			response.setDeleteStatus(false);
			return new ResponseEntity(response, HttpStatus.NOT_FOUND);
		}
	}

	

}