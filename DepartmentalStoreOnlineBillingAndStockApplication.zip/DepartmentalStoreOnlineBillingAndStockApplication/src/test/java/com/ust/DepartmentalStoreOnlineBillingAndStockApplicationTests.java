package com.ust;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DepartmentalStoreOnlineBillingAndStockApplicationTests {

	@Test
	void contextLoads() {
	}

}
